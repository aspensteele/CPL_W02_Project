/* Systems Programming Language for Micro-controllers (Sysplm) */
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>     
#include <math.h>   
 
enum Boolean {false, true};
typedef enum Boolean bool;
typedef unsigned char byte;
